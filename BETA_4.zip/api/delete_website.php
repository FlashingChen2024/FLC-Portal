<?php
// 设置响应头为JSON格式
header('Content-Type: application/json');

// 引入配置文件
require_once '../config.php';

// 启动会话
session_start();

// 检查用户是否登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => '未授权访问']);
    exit;
}

// 连接数据库
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// 检查连接
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]));
}

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);

// 验证输入数据
if (isset($data['id'])) {
    if (is_array($data['id'])) {
        // 处理批量ID
        $ids = array_map(function($id) use ($conn) {
            return intval($conn->real_escape_string(trim($id)));
        }, $data['id']);
        
        $idsStr = implode(",", $ids);
    } else {
        // 处理单个ID
        $id = intval($conn->real_escape_string(trim($data['id'])));
        $idsStr = "$id";
    }
    
    // 从数据库中删除记录
    $sql = "DELETE FROM websites WHERE id IN ($idsStr)";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => '网站删除成功', 'affected_rows' => $conn->affected_rows]);
    } else {
        echo json_encode(['success' => false, 'message' => '数据库错误: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'message' => '缺少必要参数']);
}

$conn->close();
?>