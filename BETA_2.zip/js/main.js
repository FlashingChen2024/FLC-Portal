// 首页申请加入弹窗功能
document.addEventListener('DOMContentLoaded', function() {
    // 如果在首页
    if (document.getElementById('applyBtn')) {
        const applyBtn = document.getElementById("applyBtn");
        const modal = document.getElementById("myModal");
        const closeBtn = document.getElementById("closeBtn");
        const form = document.getElementById("applyForm");

        applyBtn.addEventListener("click", function(e) {
            e.preventDefault();
            modal.style.display = "block";
        });

        closeBtn.addEventListener("click", function() {
            modal.style.display = "none";
        });

        window.addEventListener("click", function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        });

        // 表单提交处理
        form.addEventListener("submit", function(e) {
            e.preventDefault();
            
            // 获取表单数据
            const formData = {
                name: document.getElementById("name").value,
                url: document.getElementById("url").value,
                remark: document.getElementById("remark").value
            };
            
            // 发送AJAX请求到API接口
            fetch('/api/submit_website.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                alert('申请提交成功！');
                modal.style.display = "none";
                form.reset();
            })
            .catch((error) => {
                console.error('Error:', error);
                alert('申请提交失败，请重试。');
            });
        });
    }
});

// 后台管理页面功能
document.addEventListener('DOMContentLoaded', function() {
    // 如果在管理页面
    if (document.getElementById('websitesList')) {
        // 获取网站列表数据
        fetch('/api/get_websites.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    renderWebsitesTable(data.data);
                } else {
                    document.getElementById('websitesList').innerHTML = '<p>无法加载数据：' + data.message + '</p>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('websitesList').innerHTML = '<p>网络错误，请重试</p>';
            });
    }

    // 渲染网站列表表格
    function renderWebsitesTable(websites) {
        let html = '<table class="data-table">';
        html += '<tr><th>ID</th><th>名称</th><th>网址</th><th>备注</th><th>状态</th><th>操作</th></tr>';
        
        websites.forEach(function(website) {
            html += `<tr>
                <td>${website.id}</td>
                <td>${website.name}</td>
                <td><a href="${website.url}" target="_blank">${website.url}</a></td>
                <td>${website.remark || ''}</td>
                <td class="${website.status == 0 ? 'status-unreviewed' : 'status-reviewed'}">
                    ${website.status == 0 ? '未审核' : '已审核'}
                </td>
                <td class="actions">
                    <a href="#" onclick="editWebsite(${website.id})">编辑</a>
                    <a href="#" onclick="deleteWebsite(${website.id})">删除</a>
                    ${website.status == 0 ? `<a href="#" onclick="approveWebsite(${website.id})">审核</a>` : ''}
                </td>
            </tr>`;
        });
        
        html += '</table>';
        document.getElementById('websitesList').innerHTML = html;
    }
});

// 注销功能
function logout() {
    if (confirm('确定要退出登录吗？')) {
        fetch('/api/logout.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'login.php';
                }
            });
    }
}