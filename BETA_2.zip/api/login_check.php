<?php
// 设置响应头为JSON格式
header('Content-Type: application/json');

// 启动会话
session_start();

// 引入配置文件
require_once '../config.php';

// 连接数据库
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// 检查连接
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]));
}

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);

// 检查登录尝试次数和时间
$lockoutTime = 5 * 60; // 5分钟
$maxAttempts = 5;     // 最大尝试次数

// 初始化登录尝试计数器（如果不存在）
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

// 检查是否被锁定
if ($_SESSION['login_attempts'] >= $maxAttempts && 
    isset($_SESSION['last_login_attempt']) && 
    (time() - $_SESSION['last_login_attempt']) < $lockoutTime) {
    echo json_encode(['success' => false, 'message' => '由于多次登录失败，请稍后再试']);
    $conn->close();
    exit;
}

// 验证输入数据
if (isset($data['username']) && isset($data['password'])) {
    $username = $conn->real_escape_string(trim($data['username']));
    $password = $conn->real_escape_string(trim($data['password']));
    
    // 查询管理员信息
    $sql = "SELECT * FROM admins WHERE username = '$username'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        
        // 验证密码（使用MD5加密比较）
        if ($admin['password'] === md5($password)) {
            // 密码正确，重置尝试次数并设置会话
            $_SESSION['login_attempts'] = 0;
            unset($_SESSION['last_login_attempt']);
            
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $admin['username'];
            
            echo json_encode(['success' => true, 'message' => '登录成功']);
        } else {
            // 密码错误，增加尝试次数
            $_SESSION['login_attempts']++;
            $_SESSION['last_login_attempt'] = time();
            
            $remaining = max(0, $maxAttempts - $_SESSION['login_attempts']);
            $message = '用户名或密码错误';
            
            // 如果超过最大尝试次数，显示锁定信息
            if ($_SESSION['login_attempts'] >= $maxAttempts) {
                $message .= '，您已达到最大尝试次数，请5分钟后重试';
            } else {
                $message .= '，剩余尝试次数：' . $remaining;
            }
            
            echo json_encode(['success' => false, 'message' => $message]);
        }
    } else {
        // 用户名不存在，增加尝试次数
        $_SESSION['login_attempts']++;
        $_SESSION['last_login_attempt'] = time();
        
        $remaining = max(0, $maxAttempts - $_SESSION['login_attempts']);
        $message = '用户名或密码错误';
        
        // 如果超过最大尝试次数，显示锁定信息
        if ($_SESSION['login_attempts'] >= $maxAttempts) {
            $message .= '，您已达到最大尝试次数，请5分钟后重试';
        } else {
            $message .= '，剩余尝试次数：' . $remaining;
        }
        
        echo json_encode(['success' => false, 'message' => $message]);
    }
} else {
    echo json_encode(['success' => false, 'message' => '缺少必要参数']);
}

$conn->close();
?>