<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'chuansong');

// 管理员配置
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', md5('admin123')); // 使用MD5加密存储密码
?>