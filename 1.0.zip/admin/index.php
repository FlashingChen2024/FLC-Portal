<?php
// 启动会话
session_start();

// 检查用户是否登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>老陈传送门 - 管理中心</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .header {
            background-color: #007BFF;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            margin-top: 0;
            color: #333;
        }
        .user-info {
            float: right;
            margin-top: -25px;
            color: white;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-bottom: 20px;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f8f9fa;
        }
        .actions a {
            margin-right: 10px;
            color: #007BFF;
            text-decoration: none;
        }
        .actions a:hover {
            text-decoration: underline;
        }
        .status-unreviewed {
            color: #dc3545;
            font-weight: bold;
        }
        .status-reviewed {
            color: #28a745;
            font-weight: bold;
        }
        footer {
            text-align: center;
            margin-top: 50px;
            font-size: 14px;
            color: #999;
            clear: both;
        }
        .logout {
            display: inline-block;
            margin-top: 10px;
            color: #007BFF;
            text-decoration: none;
            cursor: pointer;
        }
        .logout:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- 新增网站弹窗 -->
    <div id="addWebsiteModal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeAddModal">&times;</span>
            <h2>新增网站</h2>
            <form id="addWebsiteForm">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; text-align: left; margin-bottom: 5px;">名称：</label>
                    <input type="text" id="addName" name="name" required style="width: 100%; padding: 8px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; text-align: left; margin-bottom: 5px;">网址：</label>
                    <input type="url" id="addUrl" name="url" required style="width: 100%; padding: 8px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; text-align: left; margin-bottom: 5px;">备注：</label>
                    <textarea id="addRemark" name="remark" style="width: 100%; padding: 8px; height: 100px;"></textarea>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; text-align: left; margin-bottom: 5px;">状态：</label>
                    <select id="addStatus" name="status" style="width: 100%; padding: 8px;">
                        <option value="0">未审核</option>
                        <option value="1">已审核</option>
                    </select>
                </div>
                <button type="submit" style="padding: 10px 20px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">提交新增</button>
            </form>
        </div>
    </div>
    <div class="header">
        <h1>老陈传送门 管理中心</h1>
        <div class="user-info">
            欢迎，<?php echo $_SESSION['admin_username']; ?>！
            <br>
            <span class="logout" onclick="logout()">退出登录</span>
        </div>
    </div>

    <div class="container">
        <h2>网站管理</h2>
        <a href="#" class="btn" id="addWebsiteBtn">新增网站</a>
        
        <!-- 网站列表 -->
        <div id="websitesList">
            <!-- 数据将通过AJAX加载 -->
            正在加载数据...
        </div>
    </div>

    <footer>
        网站由<a href="https://hydun.com" target="_blank">火毅盾云安全</a>提供防护及CDN加速服务
    </footer>

    <script>
        // 页面加载时获取网站列表
        document.addEventListener('DOMContentLoaded', function() {
            fetchWebsites();
        });

        // 获取网站列表数据
        function fetchWebsites() {
            fetch('/api/get_websites.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        renderWebsitesTable(data.data);
                    } else {
                        document.getElementById('websitesList').innerHTML = '<p>无法加载数据：' + data.message + '</p>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('websitesList').innerHTML = '<p>网络错误，请重试</p>';
                });
        }

        // 渲染网站列表表格
        function renderWebsitesTable(websites) {
            let html = '<table>';
            html += '<tr><th>ID</th><th>名称</th><th>网址</th><th>备注</th><th>状态</th><th>操作</th></tr>';
            
            websites.forEach(function(website) {
                html += `<tr>
                    <td>${website.id}</td>
                    <td>${website.name}</td>
                    <td><a href="${website.url}" target="_blank">${website.url}</a></td>
                    <td>${website.remark || ''}</td>
                    <td class="${website.status == 0 ? 'status-unreviewed' : 'status-reviewed'}">
                        ${website.status == 0 ? '未审核' : '已审核'}
                    </td>
                    <td class="actions">
                        <a href="#" onclick="editWebsite(${website.id})">编辑</a>
                        <a href="#" onclick="deleteWebsite(${website.id})">删除</a>
                        ${website.status == 0 ? `<a href="#" onclick="approveWebsite(${website.id})">审核</a>` : ''}
                    </td>
                </tr>`;
            });
            
            html += '</table>';
            document.getElementById('websitesList').innerHTML = html;
        }

        // 注销功能
        function logout() {
            if (confirm('确定要退出登录吗？')) {
                fetch('/api/logout.php')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            window.location.href = 'login.php';
                        }
                    });
            }
        }
    </script>
</body>
</html>