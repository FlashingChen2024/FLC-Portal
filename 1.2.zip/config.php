<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'test_flashingche');
define('DB_PASS', 'test_flashingche');
define('DB_NAME', 'test_flashingche');

// 管理员配置
define('ADMIN_USER', 'FlashingChen');
define('ADMIN_PASS', md5('evan520robby')); // 使用MD5加密存储密码
?>