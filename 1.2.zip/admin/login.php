<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>老陈传送门 - 管理员登录</title>
    <!-- 引入 Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .login-container {
            max-width: 400px;
            width: 100%;
            padding: 2rem;
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 0 1rem rgba(0,0,0,0.1);
        }
        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 1rem;
            background-color: #e9ecef;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="login-container mx-auto">
        <h2 class="text-center mb-4">管理员登录</h2>
        <form id="loginForm">
            <div class="mb-3">
                <label for="username" class="form-label">用户名：</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">密码：</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">登录</button>
            <div class="mt-3 text-center text-danger" id="errorMessage"></div>
        </form>
    </div>

    <footer>
        <p class="mb-0">网站由<a href="https://hydun.com" target="_blank" class="text-decoration-none">火毅盾云安全</a>提供防护及CDN加速服务</p>
    </footer>

    <!-- 引入 Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = {
                username: document.getElementById('username').value,
                password: document.getElementById('password').value
            };

            fetch('/api/login_check.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应异常');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    window.location.href = 'index.php';
                } else {
                    document.getElementById('errorMessage').textContent = data.message;
                    document.getElementById('errorMessage').style.display = 'block';
                }
            })
            .catch((error) => {
                console.error('Error:', error);
                document.getElementById('errorMessage').textContent = '登录失败，请重试。';
                document.getElementById('errorMessage').style.display = 'block';
            });
        });
    </script>
</body>
</html>