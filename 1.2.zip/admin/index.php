<?php
// 启动会话
session_start();

// 检查用户是否登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>老陈传送门 - 管理中心</title>
    <!-- 引入 Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .header {
            background-color: #007BFF;
            color: white;
            padding: 1rem;
        }
        .user-info {
            position: absolute;
            top: 1rem;
            right: 2rem;
        }
        .logout {
            color: #fff;
            text-decoration: none;
            cursor: pointer;
        }
        .logout:hover {
            text-decoration: underline;
        }
        .container {
            margin-top: 2rem;
            margin-bottom: 4rem;
        }
        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 1rem;
            background-color: #e9ecef;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="header text-center">
        <h1 class="mb-0">老陈传送门 管理中心</h1>
    </div>

    <div class="user-info">
        欢迎，<?php echo $_SESSION['admin_username']; ?>！<br>
        <span class="logout" onclick="logout()">退出登录</span>
    </div>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">网站管理</h2>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addWebsiteModal">
                新增网站
            </button>
        </div>

        <div class="card">
            <div class="card-body">
                <div id="websitesList">
                    正在加载数据...
                </div>
            </div>
        </div>
    </div>

    <!-- 新增网站弹窗 -->
    <div class="modal fade" id="addWebsiteModal" tabindex="-1" aria-labelledby="addWebsiteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addWebsiteModalLabel">新增网站</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addWebsiteForm">
                        <div class="mb-3">
                            <label for="addName" class="form-label">名称：</label>
                            <input type="text" class="form-control" id="addName" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="addUrl" class="form-label">网址：</label>
                            <input type="url" class="form-control" id="addUrl" name="url" required>
                        </div>
                        <div class="mb-3">
                            <label for="addRemark" class="form-label">备注：</label>
                            <textarea class="form-control" id="addRemark" name="remark" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="addStatus" class="form-label">状态：</label>
                            <select class="form-select" id="addStatus" name="status">
                                <option value="0">未审核</option>
                                <option value="1">已审核</option>
                            </select>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">提交新增</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-light text-center">
        <p>网站由<a href="https://hydun.com" target="_blank" class="text-decoration-none">火毅盾云安全</a>提供防护及CDN加速服务</p>
    </footer>

    <!-- 引入 Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/js/main.js"></script>
    <script>
        // 页面加载时获取网站列表
        document.addEventListener('DOMContentLoaded', function() {
            fetchWebsites();
            
            // 表单提交处理
            const addForm = document.getElementById("addWebsiteForm");
            if (addForm) {
                addForm.addEventListener("submit", function(e) {
                    e.preventDefault();
                    
                    // 获取表单数据
                    const formData = {
                        name: document.getElementById("addName").value,
                        url: document.getElementById("addUrl").value,
                        remark: document.getElementById("addRemark").value,
                        status: document.getElementById("addStatus").value
                    };
                    
                    // 发送AJAX请求到API接口
                    fetch('/api/add_website.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(formData)
                    })
                    .then(response => response.json())
                    .then(data => {
                        console.log('Success:', data);
                        if (data.success) {
                            alert('网站添加成功！');
                            const modal = bootstrap.Modal.getInstance(document.getElementById('addWebsiteModal'));
                            modal.hide();
                            addForm.reset();
                            fetchWebsites(); // 刷新列表
                        } else {
                            alert('添加失败：' + data.message);
                        }
                    })
                    .catch((error) => {
                        console.error('Error:', error);
                        alert('申请提交失败，请重试。');
                    });
                });
            }
        });

        // 审核网站功能
        window.approveWebsite = function(id) {
            if (confirm('确定要审核这个网站吗？')) {
                fetch('/api/approve_website.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({id: id})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('审核成功！');
                        fetchWebsites(); // 刷新列表
                    } else {
                        alert('审核失败：' + data.message);
                    }
                });
            }
        }
        
        // 删除网站功能
        window.deleteWebsite = function(id) {
            if (confirm('确定要删除这个网站吗？')) {
                fetch('/api/delete_website.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({id: id})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('删除成功！');
                        fetchWebsites(); // 刷新列表
                    } else {
                        alert('删除失败：' + data.message);
                    }
                });
            }
        }
    </script>
</body>
</html>