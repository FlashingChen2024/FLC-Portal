<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>老陈传送门</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        p {
            font-size: 1.1em;
            color: #666;
            line-height: 1.6;
            margin-bottom: 30px;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        footer {
            text-align: center;
            margin-top: 50px;
            font-size: 14px;
            color: #999;
        }
        /* 弹窗样式 */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 70%;
            border-radius: 5px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>欢迎使用老陈传送门</h1>
        <p>这是一个神奇的网站跳转平台，点击下方按钮即可申请加入我们的传送门网络。</p>
        
        <a href="#" class="btn" id="applyBtn">申请加入</a>
    </div>

    <!-- 弹窗 -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeBtn">&times;</span>
            <h2>申请加入</h2>
            <form id="applyForm">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; text-align: left; margin-bottom: 5px;">名称：</label>
                    <input type="text" id="name" name="name" required style="width: 100%; padding: 8px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; text-align: left; margin-bottom: 5px;">网址：</label>
                    <input type="url" id="url" name="url" required style="width: 100%; padding: 8px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; text-align: left; margin-bottom: 5px;">备注：</label>
                    <textarea id="remark" name="remark" style="width: 100%; padding: 8px; height: 100px;"></textarea>
                </div>
                <button type="submit" style="padding: 10px 20px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">提交申请</button>
            </form>
        </div>
    </div>

    <footer>
        网站由<a href="https://hydun.com" target="_blank">火毅盾云安全</a>提供防护及CDN加速服务
    </footer>

    <script>
        // 弹窗功能
        const applyBtn = document.getElementById("applyBtn");
        const modal = document.getElementById("myModal");
        const closeBtn = document.getElementById("closeBtn");
        const form = document.getElementById("applyForm");

        applyBtn.addEventListener("click", function(e) {
            e.preventDefault();
            modal.style.display = "block";
        });

        closeBtn.addEventListener("click", function() {
            modal.style.display = "none";
        });

        window.addEventListener("click", function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        });

        // 表单提交处理
        form.addEventListener("submit", function(e) {
            e.preventDefault();
            
            // 获取表单数据
            const formData = {
                name: document.getElementById("name").value,
                url: document.getElementById("url").value,
                remark: document.getElementById("remark").value
            };
            
            // 发送AJAX请求到API接口
            fetch('/api/submit_website.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                alert('申请提交成功！');
                modal.style.display = "none";
                form.reset();
            })
            .catch((error) => {
                console.error('Error:', error);
                alert('申请提交失败，请重试。');
            });
        });
    </script>
</body>
</html>