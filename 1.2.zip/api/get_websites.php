<?php
// 设置响应头为JSON格式
header('Content-Type: application/json');

// 引入配置文件
require_once '../config.php';

// 连接数据库
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// 检查连接
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]));
}

// 查询所有网站信息
$sql = "SELECT * FROM websites ORDER BY status ASC, created_at DESC";
$result = $conn->query($sql);

if ($result) {
    $websites = [];
    while($row = $result->fetch_assoc()) {
        $websites[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $websites]);
} else {
    echo json_encode(['success' => false, 'message' => '数据库错误: ' . $conn->error]);
}

$conn->close();
?>